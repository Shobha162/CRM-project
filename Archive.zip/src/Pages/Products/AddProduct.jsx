import React, { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { v4 as uuid } from "uuid";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { createProduct } from "../../Redux/Product/productSlice";
import ProductForm from "./ProductForm";
import PageCount from "../../Common/PageCount";
import Heading from "../../Common/Heading";
import BackButton from "../../Common/fields/BackButton";
import GradientLoader from "../../Common/GradientLoader";

export default function AddProduct() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const role = useSelector((s) => s.auth.role);

  const tempIDRef = useRef(uuid());
  const tempID = tempIDRef.current;

  const imageData = useSelector((s) => s.productMaster.images[tempID]);

  const [isCreating, setIsCreating] = useState(false);
  const [isPageLoading] = useState(false); // for structure similarity

  const handleSubmit = async (formData) => {
    const file = imageData?.file;

    const payload = {
      description: formData.description,
      hsn_uom: formData.hsn,
      rate: Number(formData.rate) || 0, // ✅ formData.price → formData.rate
      uom: formData.uom,
      currentStock: Number(formData.currentStock) || 0,
      taxPercentage: Number(formData.taxPercentage) || 0,
      image: file,
    };

    setIsCreating(true);
    try {
      await dispatch(createProduct(payload));
      navigate(`/${role}/products`);
    } catch (err) {
      toast.error(err?.message || "Product creation failed");
    } finally {
      setIsCreating(false);
    }
  };

  if (isPageLoading) {
    return (
      <PageCount>
        <div className="flex justify-center py-10">
          <GradientLoader size={30} />
        </div>
      </PageCount>
    );
  }

  return (
    <PageCount>
      <div className="flex items-center gap-3 mb-4">
        <BackButton />
        <Heading text="Add Product" />
      </div>

      <ProductForm
        defaultValues={{ id: tempID }}
        onSubmit={handleSubmit}
        isEdit={false}
        isLoading={isCreating} // ✅ Button loader
      />
    </PageCount>
  );
}
