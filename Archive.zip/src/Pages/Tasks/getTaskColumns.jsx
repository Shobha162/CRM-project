import { Trash2 } from "lucide-react";
import React from "react";

export const getTaskColumns = (onDelete, onStatusToggle, role) => {
  const columns = [
    {
      name: "Type",
      selector: (row) => {
        if (row.dataType === "reminder") {
          return `Reminder (${row.invoiceNo || "-"})`;
        }
        return row.type || "-";
      },
    },
    {
      name: "Customer Name",
      selector: (row) => {
        return Array.isArray(row.customer?.names)
          ? row.customer.names.join(", ")
          : Array.isArray(row.customerId?.names)
            ? row.customerId.names.join(", ")
            : row.customer?.name || "-";
      },
      sortable: true,
    },
    {
      name: "Alert Date",
      selector: (row) => {
        const dateField = row.alertDate || row.remainderDate || row.date;
        return dateField
          ? new Date(dateField).toLocaleDateString("en-GB")
          : "-";
      },
      sortable: true,
    },
    {
      name: "Alert Time",
      selector: (row) => {
        if (row.dataType === "task" && row.alertTime) {
          const [hours, minutes] = row.alertTime.split(":").map(Number);
          const period = hours >= 12 ? "PM" : "AM";
          const hour12 = hours % 12 || 12;
          return `${String(hour12).padStart(2, "0")}:${String(minutes).padStart(2, "0")} ${period}`;
        }
        return "-";
      },
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) => row.status || "Active",
      cell: (row) => {
        const isActive = row.status?.toLowerCase() === "active";

        return (
          <div className="flex items-center justify-center p-1 border border-gray-300 rounded">
            <label className="relative inline-flex items-center cursor-pointer">
              {/* Hidden Checkbox */}
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => {
                  e.stopPropagation();
                  onStatusToggle(row);
                }}
                className="sr-only peer"
              />

              {/* Custom Switch */}
              <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600 peer-checked:border-green-600"></div>

              {/* Status Badge */}
              <span className="ml-1 text-xs font-medium p-1 rounded-full bg-gray-100">
                {isActive ? "🟢 ACTIVE" : "🔴 INACTIVE"}
              </span>
            </label>
          </div>
        );
      },
      width: "180px",
      center: true,
      ignoreRowClick: true,
    },
    {
      name: "Note / Invoice Info",
      selector: (row) => {
        if (row.dataType === "reminder") {
          return `${row.invoiceNo || "-"} | ${row.salesPerson || "-"}`;
        }
        return row.note || "-";
      },
      wrap: true,
    },
    {
      name: "Created",
      selector: (row) =>
        row.createdAt
          ? new Date(row.createdAt).toLocaleDateString("en-GB")
          : "-",
      sortable: true,
    },
  ];

  // ✅ Delete सभी के लिए same (superAdmin के लिए)
  if (role === "superAdmin") {
    columns.push({
      name: "Actions",
      cell: (row) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete?.(row._id); // ✅ Same delete handler for ALL
          }}
          className="text-red-600 hover:text-red-800 hover:underline text-sm p-1 transition-colors"
          title={`Delete ${row.dataType === "reminder" ? "Reminder" : "Task"}`}
        >
          <Trash2 size={16} />
        </button>
      ),
      ignoreRowClick: true,
      width: "80px",
      center: true,
    });
  }

  return columns;
};
